﻿namespace P03._ShoppingCart
{
    class OnlineOrder : Order
    {
        public OnlineOrder(Cart cart)
            :base(cart)
        {

        }

    }
}

﻿using System;

namespace P03._ShoppingCart_Before
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Hello World!");
        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Newspaper
{
   public class News
    {
        public News(string title, string text, string writer)
        {
            Title = title;
            Text = text;
            Writer = writer;
        }

        public string Title { get; set; }
        public string Text { get; set; }
        public string Writer { get; set; }

        public void Rename(string newTitle)
        {
            this.Title = newTitle;
        }

        public void Edit(string newText)
        {
            this.Text = newText;
        }

        public void ChangeWriter(string newWriter)
        {
            this.Writer = newWriter;
        }
        public override string ToString()
        {
            return $"{Title} - {Text}: {Writer}";
        }
    }
}

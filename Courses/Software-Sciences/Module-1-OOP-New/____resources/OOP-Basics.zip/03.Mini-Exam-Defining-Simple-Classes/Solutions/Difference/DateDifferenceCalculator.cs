﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Difference
{
    public class DateDifferenceCalculator
    {
        public static double GetDiferenceOfDates(string dateOne, string DateTwo)
        {

            DateTime firstInput = DateTime.Parse(dateOne);
            DateTime secondInput = DateTime.Parse(DateTwo);
            double result = (secondInput - firstInput).TotalDays;
            return result;
        }
        //Second option for solving the problem:

        //public int GetDifference(string firstInput, string secondInput)
        //{
        //    string[] firstSplitInput = firstInput.Split(" ", StringSplitOptions.RemoveEmptyEntries).ToArray();
        //    int firstYear = int.Parse(firstSplitInput[0]);
        //    int firstMonth = int.Parse(firstSplitInput[1]);
        //    int firstDay = int.Parse(firstSplitInput[2]);

        //    string[] secondSplitInput = secondInput.Split(" ", StringSplitOptions.RemoveEmptyEntries).ToArray();
        //    int secondYear = int.Parse(secondSplitInput[0]);
        //    int secondMonth = int.Parse(secondSplitInput[1]);
        //    int secondDay = int.Parse(secondSplitInput[2]);

        //    DateTime firstDate = new DateTime(firstYear, firstMonth, firstDay);
        //    DateTime secondDate = new DateTime(secondYear, secondMonth, secondDay);

        //    string difference = (secondDate - firstDate).TotalDays.ToString();
        //    int result = Math.Abs(int.Parse(difference));

        //    return result;
        //}
    }
}

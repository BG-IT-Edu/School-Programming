﻿using System;

namespace Difference
{
   public class Difference
    {
        static void Main(string[] args)
        {
            double days = DateDifferenceCalculator.GetDiferenceOfDates(Console.ReadLine(), Console.ReadLine());
            Console.WriteLine(Math.Abs(days));
        }
    }
}

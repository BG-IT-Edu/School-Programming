﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace Games
{
   public class Games
    {
        static void Main(string[] args)
        {
            int countOfTeams = int.Parse(Console.ReadLine());
            List<Squad> teams = new List<Squad>(countOfTeams);

            for (int i = 0; i < countOfTeams; i++)
            {
                string[] currLine = Console.ReadLine().Split("-");
                string currTeamCreator = currLine[0];
                string currTeamName = currLine[1];
                if (Squad.isNewName(currTeamName, teams) != -1)
                {
                    Console.WriteLine($"That squad name is already taken.");
                    continue;
                }
                if (!Squad.isNewCreator(currTeamCreator, teams))
                {
                    Console.WriteLine($"{currTeamCreator} cannot set up another squad.");
                    continue;
                }

                Squad team = new Squad(currTeamCreator, currTeamName);
                teams.Add(team);
                Console.WriteLine($"{currTeamCreator} has successfully created a new squad: {currTeamName}");
            }

            string commandLine = Console.ReadLine();
            while (commandLine != "end")
            {
                string[] command = commandLine.Split("/");
                string user = command[0];
                string joiningTeam = command[1];
                int index = Squad.isNewName(joiningTeam, teams);
                if (index == -1)
                {
                    Console.WriteLine($"The squad doesn't exist.");
                    commandLine = Console.ReadLine();
                    continue;
                }
                if (Squad.userExist(user, teams))
                {
                    Console.WriteLine($"The player is already member of a squad.");
                    commandLine = Console.ReadLine();
                    continue;
                }

                teams[index].Members.Add(user);
                commandLine = Console.ReadLine();
            }

            if (Squad.isTeamWhitMembers(teams))
            {
                foreach (Squad team in teams.Where(x => x.Members.Count != 1).OrderBy(y => y.Name).OrderByDescending(x => x.Members.Count))
                {
                    Console.WriteLine(team.ToString());
                }
            }

            Console.WriteLine("Squads to detach:");
            if (Squad.isTeamWithoutMembers(teams))
            {
                foreach (Squad team in teams.Where(x => x.Members.Count == 1).OrderBy(y => y.Name))
                {
                    Console.WriteLine(team.Name);
                }
            }
        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Games
{
   public class Squad
    {
        public string Creator { get; set; }
        public string Name { get; set; }
        public List<string> Members { get; set; }

        public Squad(string creator, string name)
        {
            this.Creator = creator;
            this.Name = name;
            this.Members = new List<string>();
            this.Members.Add(creator); // first member is creator of Team
        }

        internal static bool isNewCreator(string currCreator, List<Squad> teams)
        {
            foreach (Squad item in teams.Where(x => x.Creator == currCreator))
            {
                return false;
            }

            return true;
        }

        internal static int isNewName(string currName, List<Squad> teams)
        {
            foreach (Squad item in teams.Where(x => x.Name == currName))
            {
                return teams.IndexOf(item);
            }

            return -1;
        }

        internal static bool userExist(string user, List<Squad> teams)
        {
            foreach (Squad team in teams)
            {
                if (team.Members.Contains(user))
                {
                    return true;
                }
            }

            return false;
        }

        internal static bool isTeamWithoutMembers(List<Squad> teams)
        {
            foreach (var item in teams)
            {
                if (item.Members.Count == 1)
                {
                    return true;
                }
            }

            return false;
        }

        internal static bool isTeamWhitMembers(List<Squad> teams)
        {
            foreach (var item in teams)
            {
                if (item.Members.Count != 1)
                {
                    return true;
                }
            }

            return false;
        }

        public override string ToString()
        {
            /*
             {teamName}:
             * {creator}
             ** {member}…
            */
            StringBuilder team = new StringBuilder();
            team.AppendLine($"{this.Name}");
            team.AppendLine($"* {this.Creator}");
            List<string> members = this.Members.Skip(1).ToList();
            members.Sort();
            foreach (var item in members)
            {
                team.AppendLine($"** {item}");
            }

            return team.ToString().Trim();
        }

    }
}

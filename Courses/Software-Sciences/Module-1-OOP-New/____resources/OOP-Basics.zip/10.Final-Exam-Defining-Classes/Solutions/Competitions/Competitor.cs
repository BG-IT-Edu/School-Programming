﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Diagnostics.CodeAnalysis;

namespace Competitions
{
    public class Competitor<T> : IEnumerable<T>, IComparable<Competitor<T>>
    {
        private string name;
        private List<T> scores;
        private int age;

        public Competitor(string name, int age)
        {
            this.Scores = new List<T>();
            this.Name = name;
            this.Age = age;
        }

        public List<T> Scores
        {
            get { return scores; }
            set { scores = value; }
        }

        public string Name
        {
            get { return name; }
            set { name = value; }
        }
        public int Age
        {
            get { return age; }
            set
            {
                if (value < 10 )
                {
                    throw new ArgumentOutOfRangeException("Age cannot be less than 10.");
                }
                age = value;
            }
        }

        public void Add(T score)
        {
            this.Scores.Add(score);
        }

        public int CountCompetitions()
        {
            int result = Scores.Count;
            return result;
        }
        public T ChangeLastScore(T newScore)
        {
            T oldScore = this.Scores[Scores.Count - 1];
            this.Scores[Scores.Count - 1] = newScore;
            return oldScore;
        }

        public IEnumerator<T> GetEnumerator()
        {
            foreach (var item in this.Scores)
            {
                yield return item;
            }
        }

        IEnumerator IEnumerable.GetEnumerator()
        {
            return this.GetEnumerator();
        }

        public int CompareTo([AllowNull] Competitor<T> other)
        {

            var result = this.Name.CompareTo(other.Name);
            if (result == 0)
            {
                result = this.Age.CompareTo(other.Age);
            }

            return result;
        }
    }
}

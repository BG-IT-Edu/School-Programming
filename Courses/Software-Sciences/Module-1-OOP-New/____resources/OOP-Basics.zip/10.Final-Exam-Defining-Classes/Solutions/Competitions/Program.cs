﻿using System;

namespace Competitions
{
    class Program
    {
        static void Main(string[] args)
        {
            Competitor<double> PeshoTheWiner = new Competitor<double>("Pesho", 16);
            PeshoTheWiner.Add(5.5);
            PeshoTheWiner.Add(2);
            PeshoTheWiner.Add(5.5);
            PeshoTheWiner.Add(4.5);
            Console.WriteLine(PeshoTheWiner.Name);
            Console.WriteLine(PeshoTheWiner.Age);
            Console.WriteLine(PeshoTheWiner.CountCompetitions());
            Console.WriteLine(PeshoTheWiner.ChangeLastScore(6));

            //Competitor<int> IvanTheWiner = new Competitor<int>("Ivan",16);
            //Competitor<int> Vanya = new Competitor<int>("Vanya", 17);
            //IvanTheWiner.Add(6);
            //IvanTheWiner.Add(2);
            //IvanTheWiner.Add(5);
            //IvanTheWiner.Add(4);
            //Console.WriteLine(IvanTheWiner.Name);
            //Console.WriteLine(IvanTheWiner.Age);
            ////Console.WriteLine(IvanTheWiner.GetAverageScore());
            //Console.WriteLine(IvanTheWiner.CountCompetitions());
            //Console.WriteLine(IvanTheWiner.ChangeLastScore(6));

            //Console.WriteLine();
            //foreach (var scores in IvanTheWiner)
            //{
            //    Console.WriteLine(scores);
            //}

            //Console.WriteLine(IvanTheWiner.CompareTo(Vanya));
        }
    }
}

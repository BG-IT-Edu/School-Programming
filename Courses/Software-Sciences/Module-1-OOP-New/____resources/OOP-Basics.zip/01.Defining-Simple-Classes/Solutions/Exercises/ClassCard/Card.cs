﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ClassCard
{
    public class Card
    {
        public string Face { get; set; }
        public string Suite { get; set; }

        public void Print()
        {
            Console.WriteLine($"{Face} {Suite}");
        }
    }
}

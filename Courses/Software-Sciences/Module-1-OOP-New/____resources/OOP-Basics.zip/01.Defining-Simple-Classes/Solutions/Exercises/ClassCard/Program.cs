﻿using System;
using System.Collections.Generic;

namespace ClassCard
{
    class Program
    {
        static void Main(string[] args)
        {
            //clubs (♣), diamonds (♦), hearts (♥), and spades (♠)
            List<Card> collection = new List<Card>();
            Card aSpade = new Card();
            aSpade.Face = "A";
            aSpade.Suite = "Spades";
            collection.Add(aSpade);

            Card jDiamonds = new Card();
            jDiamonds.Face = "J";
            jDiamonds.Suite = "Diamonds";
            collection.Add(jDiamonds);

            Card qClubs = new Card();
            qClubs.Face = "Q";
            qClubs.Suite = "Clubs";
            collection.Add(qClubs);

            Card tenHearts = new Card();
            tenHearts.Face = "10";
            tenHearts.Suite = "Hearts";
            collection.Add(tenHearts);

            foreach (Card card in collection)
            {
                card.Print();
            }

        }
    }
}

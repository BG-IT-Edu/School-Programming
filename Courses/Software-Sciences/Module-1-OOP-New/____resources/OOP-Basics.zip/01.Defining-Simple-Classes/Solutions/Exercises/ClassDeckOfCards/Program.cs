﻿using System;
using System.Linq;

namespace ClassDeckOfCards
{
    class Program
    {
        static void Main(string[] args)
        {
            DeckOfCards deck = new DeckOfCards();
            string input;
            while ((input = Console.ReadLine()) != "End")
            {

                string[] actions = input.Split(' ').ToArray();
                string command = actions[0];
                switch (command)
                {
                    case "Add":
                        string face = actions[1];
                        string suite = actions[2];

                        Card newCard = new Card();
                        newCard.Face = face;
                        newCard.Suite = suite;
                        deck.Add(newCard);
                        break;

                    case "Print":
                        deck.Print();
                        break;
                    case "Get":
                        deck.GetAllCards();
                        break;
                    case "Randomize":
                        deck.Shuffle();
                        break;
                    case "Clear":
                        deck.Clear();
                        break;
                    default:
                        break;
                }

            }
        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ClassDeckOfCards
{
    public class DeckOfCards
    {
        public List<Card> CardCollection = new List<Card>();
        public void Add(Card card)
        {
            CardCollection.Add(card);
        }
        public void Print()
        {
            Console.WriteLine($"{CardCollection[CardCollection.Count - 1].Face} {CardCollection[CardCollection.Count - 1].Suite}");
        }
        public void GetAllCards()
        {
            foreach (Card card in CardCollection)
            {
                card.Print();
            }
        }
        public void Shuffle()
        {
            Random random = new Random();
            for (int i = 0; i < CardCollection.Count; i++)
            {
                int randomIndex = random.Next(0, CardCollection.Count);
                Card oldCard = CardCollection[i];
                CardCollection[i] = CardCollection[randomIndex];
                CardCollection[randomIndex] = oldCard;
            }

            // Print the cards
            foreach (Card card in CardCollection)
                card.Print();
        }
        public void Clear()
        {
            CardCollection.Clear();
        }
    }
}

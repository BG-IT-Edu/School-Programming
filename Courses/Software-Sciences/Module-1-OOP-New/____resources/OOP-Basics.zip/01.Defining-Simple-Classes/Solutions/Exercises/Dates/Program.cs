﻿using System;


namespace Dates
{
    class Program
    {
        static void Main(string[] args)
        {
            string date1 = Console.ReadLine();
            string date2 = Console.ReadLine();

            DateCounter dateModifier = new DateCounter();

            Console.WriteLine(dateModifier.CalculateDifference(date1, date2));
        }
    }
}

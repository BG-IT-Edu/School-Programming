﻿using Fractions;
using System;
using System.Linq;

namespace CalculationWithFractions
{
    class Program
    {
        static void Main(string[] args)
        {
            string[] input = Console.ReadLine().Split(' ').ToArray();
            int[] firstFraction = input[0].Split('/').Select(int.Parse).ToArray();
            string sign = input[1];
            int[] secondFraction = input[2].Split('/').Select(int.Parse).ToArray();

            Fraction f1 = new Fraction(firstFraction[0], firstFraction[1]);
            Fraction f2 = new Fraction(secondFraction[0], secondFraction[1]);
            if (sign == "-")
            {
                Console.WriteLine($"{f1} - {f2} = {f1 - f2}");
            }
            else
            {
                Console.WriteLine($"{f1} + {f2} = {f1 + f2}");
            }


        }
    }
}

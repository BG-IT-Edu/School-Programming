﻿using System;
using System.Collections.Generic;

class CardsRandomizer
{
    static void Main()
    {
        // Generate a full deck of 52 cards
        List<Card> deckOfCards = new List<Card>();
        string[] faces = new string[13] {
            "2", "3", "4", "5", "6", "7", "8", "9", "10", "J", "Q", "K", "A" };
        string[] suites = new string[4] { "Spades", "Diamonds", "Clubs", "Hearts" };

        for (int i = 0; i < faces.Length; i++)
        {
            foreach (string suite in suites)
            {
                Card currentCard = new Card();
                currentCard.Face = faces[i];
                currentCard.Suite = suite;
                deckOfCards.Add(currentCard);
            }
        }

        //Shuffle cards(see https://en.wikipedia.org/wiki/Fisher%E2%80%93Yates_shuffle)
        Random random = new Random();
        for (int i = 0; i < deckOfCards.Count; i++)
        {
            int randomIndex = random.Next(0, deckOfCards.Count);
            Card oldCard = deckOfCards[i];
            deckOfCards[i] = deckOfCards[randomIndex];
            deckOfCards[randomIndex] = oldCard;
        }

        // Print the cards
        foreach (Card card in deckOfCards)
            card.Print();
    }
}

﻿using System;

public class Card
{
    public string Face { get; set; }
    public string Suite { get; set; }

    public void Print()
    {
        Console.WriteLine($"{Face} {Suite}");
    }
}

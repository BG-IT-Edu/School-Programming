﻿using System;

namespace RectangleClass
{
    class Program
    {
        static void Main(string[] args)
        {
            int width = int.Parse(Console.ReadLine());
            int height = int.Parse(Console.ReadLine());
            string color = Console.ReadLine();

            Rectangle r = new Rectangle();
            r.Width = width;
            r.Height = height;
            r.Color = color;

            int area = r.Height* r.Width;

            Console.WriteLine($"Rect({r.Width}, {r.Height}, {r.Color}) has area {area}.");

        }
    }

}
public class Rectangle
{
    public int Width { get; set; }
    public int Height { get; set; }
    public string Color { get; set; }
}

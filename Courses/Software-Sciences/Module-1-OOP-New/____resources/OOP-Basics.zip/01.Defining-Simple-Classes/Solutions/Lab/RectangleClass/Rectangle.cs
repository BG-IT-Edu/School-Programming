﻿using System;
using System.Collections.Generic;
using System.Text;

namespace RectangleClass
{
   public class Rectangle
    {
        public int Width { get; set; }
        public int Height { get; set; }
        public string Color { get; set; }
    }
}

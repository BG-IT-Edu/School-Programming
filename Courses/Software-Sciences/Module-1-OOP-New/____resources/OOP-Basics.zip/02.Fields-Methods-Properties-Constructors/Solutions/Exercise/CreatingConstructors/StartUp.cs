﻿
using System;

namespace DefiningClasses
{
    public class StartUp
    {
        static void Main(string[] args)
        {
            Person someone = new Person();
            someone.Name = "Pesho";
            someone.Age = 20;
            Person someoneTwo = new Person();
            someoneTwo.Name = "Gosho";
            someoneTwo.Age = 18;

        }
    }
}

﻿using System;

namespace ImplementLinkedList
{
    class StartUp
    {
        static void Main(string[] args)
        {
            LinkedList<string> shoppingList = new LinkedList<string>();

            shoppingList.Add("Biscuits");
            shoppingList.Add("Chips");
            shoppingList.Add("Cheese");
            shoppingList.Add("Pickles");
            shoppingList.Add("Ice cream");

            shoppingList.Add("Honey");

            for (int i = 0; i < shoppingList.Count; i++)
            {
                Console.WriteLine(shoppingList[i]);
            }


            Console.WriteLine(shoppingList.IndexOf("Ice cream"));
            Console.WriteLine(shoppingList.Contains("Honey"));
            Console.WriteLine(shoppingList[1]);
            Console.WriteLine(shoppingList.Count);
            shoppingList.Remove(3);
            shoppingList.Remove("Chips");
            Console.WriteLine(shoppingList.Count);

            foreach (var item in shoppingList)
            {
                Console.WriteLine(item);
            }
          


        }
    }
}

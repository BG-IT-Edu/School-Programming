﻿using System;

namespace ImplementCustomQueue
{
    class StartUp
    {
        static void Main(string[] args)
        {
            var queue = new CustomQueue();
            queue.Enqueue(2);
            queue.Enqueue(3);
            queue.Enqueue(4);
            Console.WriteLine(queue.Count);
            Console.WriteLine(queue.Peek());
            Console.WriteLine(queue.Dequeue());
            queue.ForEach(x => Console.WriteLine(x));
            Console.WriteLine(queue.Count);
        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ImplementLinkedList
{
   public class DynamicList
    {
        private class Node
        {
            private object element;
            private Node next;

            public object Element
            {
                get { return element; }
                set { element = value; }
            }

            public Node Next
            {
                get { return next; }
                set { next = value; }
            }

            public Node(object element)
            {
                Element = element;
                next = null;
            }

            public Node(object element, Node prevNode)
            {
                Element = element;
                prevNode.Next = this;
                next = null;
            }
        }
        private Node head;
        private Node tail;
        private int count;

        public DynamicList()
        {
            this.head = null;
            this.tail = null;
            this.count = 0;
        }
        public void Add(object item)
        {
            if (head == null)
            {
                head = new Node(item);
                tail = head;
            }
            else
            {
                Node newNode = new Node(item, tail);
                tail = newNode;
            }
            Count++;
        }

        public object Remove(int index)
        {
            if (index >= Count || index < 0)
            {
                throw new ArgumentOutOfRangeException("Invalid index: " + index);
            }
            int currentIndex = 0;
            Node currentNode = head;
            Node prevNode = null;
            while (currentIndex < index)
            {
                prevNode = currentNode;
                currentNode = currentNode.Next;
                currentIndex++;
            }
            Count--;
            if (Count == 0)
            {
                head = null;
                tail = null;
            }
            else if (prevNode == null)
            {
                head = currentNode.Next;
            }
            else
            {
                prevNode.Next = currentNode.Next;
            }
            return currentNode.Element;
        }

        public int Remove(object item)
        {
            int currentIndex = 0;
            Node currentNode = head;
            Node prevNode = null;
            while (currentNode != null) //Search еlement.
            {
                if (currentNode.Element.Equals(item))
                {
                    break;
                }
                prevNode = currentNode;
                currentNode = currentNode.Next;
                currentIndex++;
            }
            if (currentNode != null) //Remove еlement.
            {
                Count--;

                if (Count == 0)
                {
                    head = null;
                    tail = null;
                }
                else if (prevNode == null)
                {
                    head = currentNode.Next;
                }
                else
                {
                    prevNode.Next = currentNode.Next;
                }
                return currentIndex;
            }
            else
            {
                return -1; //Element is not found.
            }
        }

        public int IndexOf(object item)
        {
            int index = 0;
            Node current = head;

            while (current != null)
            {
                if (current.Element.Equals(item))
                {
                    return index;
                }

                current = current.Next;
                index++;
            }

            return -1;
        }
        public bool Contains(object item)
        {
            int index = IndexOf(item);
            bool found = (index != -1);

            return found;
        }

        public object this[int index]
        {
            get
            {
                if (index >= Count || index < 0)
                {
                    throw new ArgumentOutOfRangeException("Invalid index: " + index);
                }

                Node currentNode = this.head;
                for (int i = 0; i < index; i++)

                {
                    currentNode = currentNode.Next;
                }
                return currentNode.Element;
            }
            set
            {
                if (index >= Count || index < 0)
                {
                    throw new ArgumentOutOfRangeException("Invalid index: " + index);
                }

                Node currentNode = this.head;
                for (int i = 0; i < index; i++)

                {
                    currentNode = currentNode.Next;
                }
                currentNode.Element = value;
            }
        }

        public int Count
        {
            get { return count; }
            private set { count = value; }
        }

    }
}

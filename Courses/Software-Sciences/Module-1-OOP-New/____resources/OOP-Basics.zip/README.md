# Object Oriented Programming - Basics (OOP Basics)

First steps in object-oriented programming (OOP): defining of simple classes (**90 hours**).

This course is a natural continuation after the "Programming Basics" and "Programming Fundamentals" courses.

## Course Program

1. Defining Simple Classes
    - Objects
    - Classes
    - Built-in API Classes
    - Defining Simple Classes


2. Fields, Methods, Properties, Constructors
    - Fields and Properties
    - Methods
    - Constructors
    - Static Classes and Members


3. Mini Exam: Defining Simple Classes


4. Implementing Array List
    - List Structures in .NET
    - Resizable Arrays
    - ArrayList Implementation


5. Implementing Linked List
    - Array-Based List
    - Linked List 
    - Linked List Implementation
    
    
6. Implementing Stack And Queue
    - Stacks 
      - Array-Based Implementation
      - Linked Stack Implementation
    - Queues
      - Array-Based Circular Queue
      - Linked Queue Implementation


7. Mini Exam: Linear Structures


8. Generics
    - Generics
    - Generic Classes
    - Generic Methods
    - Generic Constraints


9. Iterators and Comparators
    - Iterators
      - IEnumerable<T> 
      - Yield return 
      - Params
    - Comparators
      - IComparable<T> 
      - IComparer<T>
    
    
11. Final Exam: Defining Classes


## Learning Objectives

This course matches partially the courses:
 - The "[C# Advanced](https://softuni.bg/trainings/3007/csharp-advanced-september-2020)" course from SoftUni.
 - The "[Data Structures and Algorithms Basics](https://github.com/BG-IT-Edu/School-Programming/tree/main/Courses/Applied-Programmer/Algo-and-Data-Structures-Basics)" course from the official "Applied Programmer" curriculum.
 - The "[OOP Basics](https://github.com/BG-IT-Edu/School-Programming/tree/main/Courses/Applied-Programmer/OOP-Basics)" course from the official "Applied Programmer" curriculum.

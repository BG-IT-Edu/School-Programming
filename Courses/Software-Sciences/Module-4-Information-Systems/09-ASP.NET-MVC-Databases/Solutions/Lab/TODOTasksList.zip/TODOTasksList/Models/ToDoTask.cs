﻿using System;
using System.Collections.Generic;

#nullable disable

namespace TODOTasksList.Models
{
    public partial class ToDoTask
    {
        public int Id { get; set; }
        public string Title { get; set; }
    }
}

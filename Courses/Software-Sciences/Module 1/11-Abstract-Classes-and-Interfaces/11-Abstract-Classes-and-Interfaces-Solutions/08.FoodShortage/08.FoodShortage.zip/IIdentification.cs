﻿using System;
using System.Collections.Generic;
using System.Text;

namespace FoodShortage
{
    public interface IIdentification
    {
        public string Id { get;}
    }
}

﻿using System;
using System.Collections.Generic;

namespace PermutationsRepetitions
{
    public class PermutationsRepetition
    {
        private static string[] permutations;

        public static void Main()
        {
            permutations = Console.ReadLine()
                .Split();
            GeneratePermutations(0);
        }

        private static void GeneratePermutations(int index)
        {
        }

        private static void Swap(int first, int second)
        {
            (permutations[first], permutations[second]) = (permutations[second], permutations[first]);
        }
    }
}

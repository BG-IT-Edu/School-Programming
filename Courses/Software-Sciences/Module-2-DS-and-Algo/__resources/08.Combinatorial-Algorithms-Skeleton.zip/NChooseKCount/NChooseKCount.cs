﻿using System;

namespace NChooseKCount
{
    public class NChooseKCount
    {
        public static void Main()
        {
            int n = int.Parse(Console.ReadLine());
            int k = int.Parse(Console.ReadLine());
            Console.WriteLine(Binom(n, k));
        }

        private static int Binom(int row, int col)
        {
            throw new NotImplementedException();
        }
    }
}

﻿using System;

namespace PermutationsNoRepetitions
{
    public class PermutationsNoRepetition
    {
        private static string[] input;
        private static string[] permutations;
        private static bool[] isUsed;

        public static void Main()
        {
            input = Console.ReadLine()
                .Split();
            permutations = new string[input.Length];
            isUsed = new bool[input.Length];

            GeneratePermutations(0);
        }

        private static void GeneratePermutations(int index)
        {
        }
    }
}

﻿using System;

namespace VariationsNoRepetition
{
    public class VariationNoRepetition
    {
        private static int k;
        private static string[] input;
        private static string[] variations;
        private static bool[] isUsed;

        public static void Main()
        {
            input = Console.ReadLine()
                .Split();
            k = int.Parse(Console.ReadLine());
            variations = new string[k];
            isUsed = new bool[input.Length];

            GenerateVariations(0);
        }

        private static void GenerateVariations(int index)
        {
        }
    }
}

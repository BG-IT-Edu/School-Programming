using System;
using System.Collections.Generic;
using System.Linq;

using NUnit.Framework;

namespace People.Tests
{
    public class PersonTests
    {
        private PersonCollection people;

        [SetUp]
        public void Setup()
        {
            this.people = new PersonCollection();
        }

        // Performance

        [Test]
        [Timeout(250)]
        public void TestPerformance_AddPerson()
        {
            // Act
            this.AddPersons(5000, this.people);

            // Assert
            Assert.AreEqual(5000, this.people.Count);
        }

        [Test]
        [Timeout(300)]
        public void TestPerformance_FindPerson()
        {
            // Arrange
            this.AddPersons(5000, this.people);

            // Act & Assert
            for (int i = 0; i < 100000; i++)
            {
                Person existingPerson = this.people.FindPerson("pesho1@gmail1.com");
                Assert.IsNotNull(existingPerson);
                Person nonExistingPerson = this.people.FindPerson("non-existing email");
                Assert.IsNull(nonExistingPerson);
            }
        }

        [Test]
        [Timeout(300)]
        public void TestPerformance_FindPersonsByEmailDomain()
        {
            // Arrange
            this.AddPersons(5000, this.people);

            // Act & Assert
            for (int i = 0; i < 10000; i++)
            {
                List<Person> existingPersons =
                    this.people.FindPeople("gmail1.com").ToList();
                Assert.AreEqual(50, existingPersons.Count);
                List<Person> notExistingPersons =
                    this.people.FindPeople("non-existing email").ToList();
                Assert.AreEqual(0, notExistingPersons.Count);
            }
        }

        [Test]
        [Timeout(300)]
        public void TestPerformance_FindPersonsByNameAndTown()
        {
            // Arrange
            this.AddPersons(5000, this.people);

            // Act & Assert
            for (int i = 0; i < 10000; i++)
            {
                List<Person> existingPersons =
                    this.people.FindPeople("Pesho1", "Sofia1").ToList();
                Assert.AreEqual(50, existingPersons.Count);
                List<Person> notExistingPersons =
                    this.people.FindPeople("Pesho1", "Sofia5").ToList();
                Assert.AreEqual(0, notExistingPersons.Count);
            }
        }

        // Functionality

        [Test]
        public void AddPerson_ShouldWorkCorrectly()
        {
            // Act
            bool isAdded = this.people.AddPerson("pesho@gmail.com", "Peter", 18, "Sofia");

            // Assert
            Assert.IsTrue(isAdded);
            Assert.AreEqual(1, this.people.Count);
        }

        [Test]
        public void AddPerson_DuplicatedEmail_ShouldWorkCorrectly()
        {
            // Act
            bool isAddedFirst = this.people.AddPerson("pesho@gmail.com", "Peter", 18, "Sofia");
            bool isAddedSecond = this.people.AddPerson("pesho@gmail.com", "Maria", 24, "Plovdiv");

            // Assert
            Assert.IsTrue(isAddedFirst);
            Assert.IsFalse(isAddedSecond);
            Assert.AreEqual(1, this.people.Count);
        }

        [Test]
        public void FindPerson_ExistingPerson_ShouldReturnPerson()
        {
            // Arrange
            this.people.AddPerson("pesho@gmail.com", "Peter", 28, "Plovdiv");

            // Act
            Person person = this.people.FindPerson("pesho@gmail.com");

            // Assert
            Assert.IsNotNull(person);
        }

        [Test]
        public void FindPerson_NonExistingPerson_ShouldReturnNothing()
        {
            // Act
            Person person = this.people.FindPerson("pesho@gmail.com");

            // Assert
            Assert.IsNull(person);
        }

        [Test]
        public void DeletePerson_ShouldWorkCorrectly()
        {
            // Arrange
            this.people.AddPerson("pesho@gmail.com", "Peter", 28, "Plovdiv");

            // Act
            bool isDeletedExisting = this.people.DeletePerson("pesho@gmail.com");
            bool isDeletedNonExisting = this.people.DeletePerson("pesho@gmail.com");

            // Assert
            Assert.IsTrue(isDeletedExisting);
            Assert.IsFalse(isDeletedNonExisting);
            Assert.AreEqual(0, this.people.Count);
        }

        [Test]
        public void FindPersonsByEmailDomain_ShouldReturnMatchingPersons()
        {
            // Arrange
            this.people.AddPerson("pesho@gmail.com", "Pesho", 28, "Plovdiv");
            this.people.AddPerson("kiro@yahoo.co.uk", "Kiril", 22, "Sofia");
            this.people.AddPerson("mary@gmail.com", "Maria", 21, "Plovdiv");
            this.people.AddPerson("ani@gmail.com", "Anna", 19, "Bourgas");

            // Act
            IEnumerable<Person> peopleGmail = this.people.FindPeople("gmail.com");
            IEnumerable<Person> peopleYahoo = this.people.FindPeople("yahoo.co.uk");
            IEnumerable<Person> peopleHoo = this.people.FindPeople("hoo.co.uk");

            // Assert
            CollectionAssert.AreEqual(new[] { "ani@gmail.com", "mary@gmail.com", "pesho@gmail.com" },
                peopleGmail.Select(p => p.Email).ToList());
            CollectionAssert.AreEqual(new[] { "kiro@yahoo.co.uk" }, 
                peopleYahoo.Select(p => p.Email).ToList());
            CollectionAssert.AreEqual(Array.Empty<string>(), 
                peopleHoo.Select(p => p.Email).ToList());
        }

        [Test]
        public void FindPersonsByNameAndTown_ShouldReturnMatchingPersons()
        {
            // Arrange
            this.people.AddPerson("pesho@gmail.com", "Pesho", 28, "Plovdiv");
            this.people.AddPerson("kiro@yahoo.co.uk", "Kiril", 22, "Sofia");
            this.people.AddPerson("pepi@gmail.com", "Pesho", 21, "Plovdiv");
            this.people.AddPerson("ani@gmail.com", "Anna", 19, "Bourgas");
            this.people.AddPerson("pepi2@yahoo.fr", "Pesho", 21, "Plovdiv");

            // Act
            IEnumerable<Person> peoplePeshoPlovdiv = this.people.FindPeople("Pesho", "Plovdiv");
            IEnumerable<Person> peopleLowercase = this.people.FindPeople("pesho", "plovdiv");
            IEnumerable<Person> peoplePeshoNoTown = this.people.FindPeople("Pesho", null);
            IEnumerable<Person> peopleAnnaBourgas = this.people.FindPeople("Anna", "Bourgas");

            // Assert
            CollectionAssert.AreEqual(new[] { "pepi@gmail.com", "pepi2@yahoo.fr", "pesho@gmail.com" },
                peoplePeshoPlovdiv.Select(p => p.Email).ToList());
            CollectionAssert.AreEqual(Array.Empty<string>(),
                peopleLowercase.Select(p => p.Email).ToList());
            CollectionAssert.AreEqual(Array.Empty<string>(),
                peoplePeshoNoTown.Select(p => p.Email).ToList());
            CollectionAssert.AreEqual(new[] { "ani@gmail.com" },
                peopleAnnaBourgas.Select(p => p.Email).ToList());
        }

        [Test]
        public void FindDeletedPersons_ShouldReturnEmptyCollection()
        {
            // Arrange
            this.people.AddPerson("pesho@gmail.com", "Pesho", 28, "Plovdiv");
            this.people.AddPerson("kirosofia@yahoo.co.uk", "Kiril", 22, "Sofia");
            this.people.AddPerson("kiro@yahoo.co.uk", "Kiril", 22, "Plovdiv");
            this.people.AddPerson("pepi@gmail.com", "Pesho", 21, "Plovdiv");
            this.people.AddPerson("ani@gmail.com", "Anna", 19, "Bourgas");
            this.people.AddPerson("ani17@gmail.com", "Anna", 17, "Bourgas");
            this.people.AddPerson("pepi2@yahoo.fr", "Pesho", 21, "Plovdiv");
            this.people.AddPerson("asen.rousse@gmail.com", "Asen", 21, "Rousse");
            this.people.AddPerson("asen@gmail.com", "Asen", 21, "Plovdiv");

            this.people.DeletePerson("pesho@gmail.com");
            this.people.DeletePerson("kirosofia@yahoo.co.uk");
            this.people.DeletePerson("kiro@yahoo.co.uk");
            this.people.DeletePerson("pepi@gmail.com");
            this.people.DeletePerson("ani@gmail.com");
            this.people.DeletePerson("ani17@gmail.com");
            this.people.DeletePerson("pepi2@yahoo.fr");
            this.people.DeletePerson("asen.rousse@gmail.com");
            this.people.DeletePerson("asen@gmail.com");

            // Act
            Person personPeshoGmail = this.people.FindPerson("pesho@gmail.com");

            IEnumerable<Person> peopleGmail = this.people.FindPeople("gmail.com");
            IEnumerable<Person> peopleYahoo = this.people.FindPeople("yahoo.co.uk");
            IEnumerable<Person> peoplePeshoPlovdiv = this.people.FindPeople("Pesho", "Plovdiv");

            // Assert
            Assert.AreEqual(null, personPeshoGmail);
            Assert.AreEqual(0, peopleGmail.Count());
            Assert.AreEqual(0, peopleYahoo.Count());
            Assert.AreEqual(0, peoplePeshoPlovdiv.Count());
        }

        [Test]
        public void MultipleOperations_ShouldReturnWorkCorrectly()
        {
            bool isAdded = this.people.AddPerson("pesho@gmail.com", "Pesho", 28, "Plovdiv");
            Assert.IsTrue(isAdded);
            Assert.AreEqual(1, this.people.Count);

            isAdded = this.people.AddPerson("pesho@gmail.com", "Pesho2", 222, "Plovdiv222");
            Assert.IsFalse(isAdded);
            Assert.AreEqual(1, this.people.Count);

            this.people.AddPerson("kiro@yahoo.co.uk", "Kiril", 22, "Plovdiv");
            Assert.AreEqual(2, this.people.Count);

            this.people.AddPerson("asen@gmail.com", "Asen", 22, "Sofia");
            Assert.AreEqual(3, this.people.Count);

            Person person = this.people.FindPerson("non-existing person");
            Assert.IsNull(person);

            person = this.people.FindPerson("pesho@gmail.com");
            Assert.IsNotNull(person);
            Assert.AreEqual("pesho@gmail.com", person.Email);
            Assert.AreEqual("Pesho", person.Name);
            Assert.AreEqual(28, person.Age);
            Assert.AreEqual("Plovdiv", person.Town);

            IEnumerable<Person> peopleGmail = this.people.FindPeople("gmail.com");
            CollectionAssert.AreEqual(new[] { "asen@gmail.com", "pesho@gmail.com" },
                peopleGmail.Select(p => p.Email).ToList());

            IEnumerable<Person> peoplePeshoPlovdiv = this.people.FindPeople("Pesho", "Plovdiv");
            CollectionAssert.AreEqual(new[] { "pesho@gmail.com" },
                peoplePeshoPlovdiv.Select(p => p.Email).ToList());

            IEnumerable<Person> peoplePeshoSofia = this.people.FindPeople("Pesho", "Sofia");
            Assert.AreEqual(0, peoplePeshoSofia.Count());

            IEnumerable<Person> peopleKiroPlovdiv = this.people.FindPeople("Kiro", "Plovdiv");
            Assert.AreEqual(0, peopleKiroPlovdiv.Count());

            bool isDeleted = this.people.DeletePerson("pesho@gmail.com");
            Assert.IsTrue(isDeleted);

            isDeleted = this.people.DeletePerson("pesho@gmail.com");
            Assert.IsFalse(isDeleted);

            person = this.people.FindPerson("pesho@gmail.com");
            Assert.IsNull(person);

            peopleGmail = this.people.FindPeople("gmail.com");
            CollectionAssert.AreEqual(new[] { "asen@gmail.com" },
                peopleGmail.Select(p => p.Email).ToList());

            peoplePeshoPlovdiv = this.people.FindPeople("Pesho", "Plovdiv");
            CollectionAssert.AreEqual(Array.Empty<string>(),
                peoplePeshoPlovdiv.Select(p => p.Email).ToList());

            peoplePeshoSofia = this.people.FindPeople("Pesho", "Sofia");
            Assert.AreEqual(0, peoplePeshoSofia.Count());

            peopleKiroPlovdiv = this.people.FindPeople("Kiro", "Plovdiv");
            Assert.AreEqual(0, peopleKiroPlovdiv.Count());
        }

        private void AddPersons(int count, PersonCollection people)
        {
            for (int i = 0; i < count; i++)
            {
                this.people.AddPerson($"pesho{i}@gmail{i % 100}.com", $"Pesho{i % 100}",
                    i % 100, $"Sofia{i % 100}");
            }
        }
    }
}

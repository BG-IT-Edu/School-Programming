﻿using System;
using System.Collections.Generic;

namespace People
{
    public class PersonCollection
    {
        public int Count => throw new NotImplementedException();

        public bool AddPerson(string email, string name, int age, string town)
        {
            throw new NotImplementedException();
        }

        public Person FindPerson(string email)
        {
            throw new NotImplementedException();
        }

        public bool DeletePerson(string email)
        {
            throw new NotImplementedException();
        }

        public IEnumerable<Person> FindPeople2(string emailDomain)
        {
            throw new NotImplementedException();
        }

        public IEnumerable<Person> FindPeople(string name, string town)
        {
            throw new NotImplementedException();
        }
    }
}

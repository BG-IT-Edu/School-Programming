﻿using System.Collections.Generic;
using System.Linq;

namespace People
{
    public static class DictionaryExtension
    {
        public static void AppendValueToKey<TKey, TCollection, TValue>(
            this IDictionary<TKey, TCollection> dict, TKey key, TValue value)
            where TCollection : ICollection<TValue>, new()
        {
            if (!dict.TryGetValue(key, out TCollection collection))
            {
                collection = new TCollection();
                dict.Add(key, collection);
            }

            collection.Add(value);
        }

        public static IEnumerable<TValue> GetValuesForKey<TKey, TValue>(
            this IDictionary<TKey, SortedSet<TValue>> dict, TKey key)
        {
            if (dict.TryGetValue(key, out SortedSet<TValue> collection))
            {
                return collection;
            }

            return Enumerable.Empty<TValue>();
        }
    }
}

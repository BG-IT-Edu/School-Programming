﻿using System;
using System.Collections.Generic;

using Wintellect.PowerCollections;

namespace ShoppingCenter
{
    public class ShoppingStructure
    {
        public string AddProduct(string name, decimal price, string producer)
        {
            throw new NotImplementedException();
        }

        public string DeleteProducts(string producer)
        {
            throw new NotImplementedException();

        }

        public string DeleteProducts(string name, string producer)
        {
            throw new NotImplementedException();

        }

        public string FindProductsByName(string name)
        {
            throw new NotImplementedException();

        }

        public string FindProductsByProducer(string producer)
        {
            throw new NotImplementedException();

        }

        public string FindProductsByPriceRange(decimal startPrice, decimal endPrice)
        {
            throw new NotImplementedException();

        }
    }
}

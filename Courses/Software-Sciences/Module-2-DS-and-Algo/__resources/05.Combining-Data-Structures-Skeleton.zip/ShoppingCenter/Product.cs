﻿using System;

namespace ShoppingCenter
{
    public class Product : IComparable<Product>
    {
        public Product(string name, decimal price, string producer)
        {
            this.Name = name;
            this.Price = price;
            this.Producer = producer;
        }

        public string Name { get; }

        public decimal Price { get; }

        public string Producer { get; }

        public int CompareTo(Product other)
        {
            int compareByName = this.Name.CompareTo(other.Name);
            if (compareByName != 0)
            {
                return compareByName;
            }

            int compareByProducer = this.Producer.CompareTo(other.Producer);
            return compareByProducer == 0 
                ? this.Price.CompareTo(other.Price) 
                : compareByProducer;
        }

        public override string ToString()
        {
            return $"{{{this.Name};{this.Producer};{this.Price.ToString("0.00")}}}";
        }
    }
}

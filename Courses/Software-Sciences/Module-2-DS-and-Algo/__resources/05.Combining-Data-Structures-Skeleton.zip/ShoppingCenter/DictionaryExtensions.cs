﻿using System.Collections.Generic;

namespace ShoppingCenter
{
    public static class DictionaryExtensions
    {
        public static void AddValueToCollection<TKey, TValue, TCollection>(
            this IDictionary<TKey, TCollection> dict, TKey key, TValue value)
            where TCollection : ICollection<TValue>, new()
        {
            if (!dict.TryGetValue(key, out TCollection collection))
            {
                collection = new TCollection();
                dict.Add(key, collection);
            }

            dict[key].Add(value);
        }
    }
}

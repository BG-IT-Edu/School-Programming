﻿namespace Book.Tests
{
    using System;

    using NUnit.Framework;

    public class Tests
    {
    }
}
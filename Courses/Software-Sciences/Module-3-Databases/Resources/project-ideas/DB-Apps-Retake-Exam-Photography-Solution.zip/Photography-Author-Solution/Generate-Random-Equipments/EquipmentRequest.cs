﻿namespace Generate_Random_Equipments
{
    class EquipmentRequest
    {
        public int GenerateCount { get; set; }

        public string Manufacturer { get; set; }
    }
}

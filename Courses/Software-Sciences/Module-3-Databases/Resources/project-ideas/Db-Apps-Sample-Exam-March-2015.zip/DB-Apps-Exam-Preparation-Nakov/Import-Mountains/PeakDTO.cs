﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Import_Mountains
{
    class PeakDTO
    {
        public string PeakName { get; set; }
        public int? Elevation { get; set; }
    }
}

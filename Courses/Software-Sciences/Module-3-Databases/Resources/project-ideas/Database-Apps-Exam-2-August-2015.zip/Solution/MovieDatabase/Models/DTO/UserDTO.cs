﻿namespace MovieDatabase.Models.DTO
{
    public class UserDTO
    {
        public string Username { get; set; }

        public string Email { get; set; }

        public int? Age { get; set; }

        public string Country { get; set; }
    }
}

﻿namespace MovieDatabase.Models.DTO
{
    public class CountryDTO
    {
        public string Name { get; set; }
    }
}

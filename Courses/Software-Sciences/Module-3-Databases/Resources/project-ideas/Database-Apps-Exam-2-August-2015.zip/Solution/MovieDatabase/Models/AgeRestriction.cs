﻿namespace MovieDatabase.Models
{
    public enum AgeRestriction
    {
        Child,
        Teen,
        Adult
    }
}

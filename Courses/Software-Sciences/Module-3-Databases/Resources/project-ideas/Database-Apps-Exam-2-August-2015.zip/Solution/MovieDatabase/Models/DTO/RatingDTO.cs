﻿namespace MovieDatabase.Models.DTO
{
    public class RatingDTO
    {
        public string Movie { get; set; }

        public string User { get; set; }

        public int Rating { get; set; }
    }
}

﻿namespace WinFormsAppTownsDb
{
	public partial class FormDeleteTown : Form
	{
		public FormDeleteTown(string townName)
		{
			InitializeComponent();
			this.textBoxTownName.Text = townName;
		}
	}
}

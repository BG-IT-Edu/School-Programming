﻿namespace WinFormsAppTownsDb
{
	partial class FormTowns
	{
		/// <summary>
		///  Required designer variable.
		/// </summary>
		private System.ComponentModel.IContainer components = null;

		/// <summary>
		///  Clean up any resources being used.
		/// </summary>
		/// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
		protected override void Dispose(bool disposing)
		{
			if (disposing && (components != null))
			{
				components.Dispose();
			}
			base.Dispose(disposing);
		}

		#region Windows Form Designer generated code

		/// <summary>
		///  Required method for Designer support - do not modify
		///  the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			listBoxTowns = new ListBox();
			buttonAddTown = new Button();
			buttonDeleteTown = new Button();
			SuspendLayout();
			// 
			// listBoxTowns
			// 
			listBoxTowns.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
			listBoxTowns.FormattingEnabled = true;
			listBoxTowns.Location = new Point(12, 12);
			listBoxTowns.Name = "listBoxTowns";
			listBoxTowns.Size = new Size(212, 424);
			listBoxTowns.TabIndex = 0;
			// 
			// buttonAddTown
			// 
			buttonAddTown.Anchor = AnchorStyles.Top | AnchorStyles.Right;
			buttonAddTown.Location = new Point(242, 12);
			buttonAddTown.Name = "buttonAddTown";
			buttonAddTown.Size = new Size(166, 29);
			buttonAddTown.TabIndex = 1;
			buttonAddTown.Text = "Добави град";
			buttonAddTown.UseVisualStyleBackColor = true;
			buttonAddTown.Click += buttonAddTown_Click;
			// 
			// buttonDeleteTown
			// 
			buttonDeleteTown.Anchor = AnchorStyles.Top | AnchorStyles.Right;
			buttonDeleteTown.Location = new Point(242, 58);
			buttonDeleteTown.Name = "buttonDeleteTown";
			buttonDeleteTown.Size = new Size(166, 29);
			buttonDeleteTown.TabIndex = 2;
			buttonDeleteTown.Text = "Изтрий град";
			buttonDeleteTown.UseVisualStyleBackColor = true;
			buttonDeleteTown.Click += buttonDeleteTown_Click;
			// 
			// FormTowns
			// 
			AutoScaleDimensions = new SizeF(8F, 20F);
			AutoScaleMode = AutoScaleMode.Font;
			ClientSize = new Size(424, 450);
			Controls.Add(buttonDeleteTown);
			Controls.Add(buttonAddTown);
			Controls.Add(listBoxTowns);
			MinimumSize = new Size(400, 200);
			Name = "FormTowns";
			StartPosition = FormStartPosition.CenterScreen;
			Text = "Градове";
			Load += FormTowns_Load;
			ResumeLayout(false);
		}

		#endregion

		private ListBox listBoxTowns;
		private Button buttonAddTown;
		private Button buttonDeleteTown;
	}
}

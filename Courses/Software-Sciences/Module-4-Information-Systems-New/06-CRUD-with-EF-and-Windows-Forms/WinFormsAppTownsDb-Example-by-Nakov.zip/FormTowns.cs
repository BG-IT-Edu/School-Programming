using WinFormsAppTownsDb.Models;

namespace WinFormsAppTownsDb
{
	public partial class FormTowns : Form
	{
		public FormTowns()
		{
			InitializeComponent();
		}

		private void FormTowns_Load(object sender, EventArgs e)
		{
			ReloadTowns();
		}

		private void ReloadTowns()
		{
			Town[] towns = LoadTownsFromDb();
			this.listBoxTowns.DataSource = towns;
			this.listBoxTowns.DisplayMember = "Name";
		}

		private Town[] LoadTownsFromDb()
		{
			using (var db = new TownsDbContext())
			{
				return db.Towns.ToArray();
			}
		}
		private void buttonAddTown_Click(object sender, EventArgs e)
		{
			FormCreateNewTown formCreateNewTown = new FormCreateNewTown();
			if (formCreateNewTown.ShowDialog() == DialogResult.OK)
			{
				string newTownName = formCreateNewTown.TownName;
				AddNewTown(newTownName);
				ReloadTowns();
			}
		}

		private void AddNewTown(string townName)
		{
			using (var db = new TownsDbContext())
			{
				Town newTown = new Town();
				newTown.Name = townName;
				db.Towns.Add(newTown);
				db.SaveChanges();
			}
		}

		private void buttonDeleteTown_Click(object sender, EventArgs e)
		{
			Town selectedTown = (Town) this.listBoxTowns.SelectedItem;
			if (selectedTown == null)
			{
				// No town is selected for deleting --> exit
				return;
			}

			string townName = selectedTown.Name;
			FormDeleteTown formDeleteTown = new FormDeleteTown(townName);
			if (formDeleteTown.ShowDialog() == DialogResult.OK)
			{
				DeleteTown(selectedTown);
				ReloadTowns();
			}
		}

		private void DeleteTown(Town town)
		{
			using (var db = new TownsDbContext())
			{
				db.Towns.Remove(town);
				db.SaveChanges();
			}
		}
	}
}

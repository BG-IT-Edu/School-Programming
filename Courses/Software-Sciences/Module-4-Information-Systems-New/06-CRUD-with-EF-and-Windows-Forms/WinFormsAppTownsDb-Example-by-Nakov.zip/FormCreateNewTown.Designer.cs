﻿namespace WinFormsAppTownsDb
{
	partial class FormCreateNewTown
	{
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.IContainer components = null;

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		/// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
		protected override void Dispose(bool disposing)
		{
			if (disposing && (components != null))
			{
				components.Dispose();
			}
			base.Dispose(disposing);
		}

		#region Windows Form Designer generated code

		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			labelTownName = new Label();
			textBoxTownName = new TextBox();
			buttonAdd = new Button();
			buttonCancel = new Button();
			SuspendLayout();
			// 
			// labelTownName
			// 
			labelTownName.AutoSize = true;
			labelTownName.Location = new Point(12, 9);
			labelTownName.Name = "labelTownName";
			labelTownName.Size = new Size(98, 20);
			labelTownName.TabIndex = 0;
			labelTownName.Text = "Име на град:";
			// 
			// textBoxTownName
			// 
			textBoxTownName.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
			textBoxTownName.Location = new Point(12, 32);
			textBoxTownName.Name = "textBoxTownName";
			textBoxTownName.Size = new Size(301, 27);
			textBoxTownName.TabIndex = 1;
			// 
			// buttonAdd
			// 
			buttonAdd.Anchor = AnchorStyles.Bottom | AnchorStyles.Right;
			buttonAdd.DialogResult = DialogResult.OK;
			buttonAdd.Location = new Point(103, 72);
			buttonAdd.Name = "buttonAdd";
			buttonAdd.Size = new Size(98, 29);
			buttonAdd.TabIndex = 2;
			buttonAdd.Text = "Добави";
			buttonAdd.UseVisualStyleBackColor = true;
			// 
			// buttonCancel
			// 
			buttonCancel.Anchor = AnchorStyles.Bottom | AnchorStyles.Right;
			buttonCancel.DialogResult = DialogResult.Cancel;
			buttonCancel.Location = new Point(218, 72);
			buttonCancel.Name = "buttonCancel";
			buttonCancel.Size = new Size(94, 29);
			buttonCancel.TabIndex = 3;
			buttonCancel.Text = "Отказ";
			buttonCancel.UseVisualStyleBackColor = true;
			// 
			// FormCreateNewTown
			// 
			AutoScaleDimensions = new SizeF(8F, 20F);
			AutoScaleMode = AutoScaleMode.Font;
			ClientSize = new Size(324, 114);
			Controls.Add(buttonCancel);
			Controls.Add(buttonAdd);
			Controls.Add(textBoxTownName);
			Controls.Add(labelTownName);
			FormBorderStyle = FormBorderStyle.FixedDialog;
			MaximizeBox = false;
			MinimizeBox = false;
			Name = "FormCreateNewTown";
			StartPosition = FormStartPosition.CenterParent;
			Text = "Добавяне на град";
			ResumeLayout(false);
			PerformLayout();
		}

		#endregion

		private Label labelTownName;
		private TextBox textBoxTownName;
		private Button buttonAdd;
		private Button buttonCancel;
	}
}
﻿namespace WinFormsAppTownsDb
{
	partial class FormDeleteTown
	{
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.IContainer components = null;

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		/// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
		protected override void Dispose(bool disposing)
		{
			if (disposing && (components != null))
			{
				components.Dispose();
			}
			base.Dispose(disposing);
		}

		#region Windows Form Designer generated code

		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			buttonCancel = new Button();
			buttonDelete = new Button();
			textBoxTownName = new TextBox();
			labelDeleteTown = new Label();
			SuspendLayout();
			// 
			// buttonCancel
			// 
			buttonCancel.DialogResult = DialogResult.Cancel;
			buttonCancel.Location = new Point(198, 83);
			buttonCancel.Name = "buttonCancel";
			buttonCancel.Size = new Size(94, 29);
			buttonCancel.TabIndex = 7;
			buttonCancel.Text = "Отказ";
			buttonCancel.UseVisualStyleBackColor = true;
			// 
			// buttonDelete
			// 
			buttonDelete.DialogResult = DialogResult.OK;
			buttonDelete.Location = new Point(84, 83);
			buttonDelete.Name = "buttonDelete";
			buttonDelete.Size = new Size(98, 29);
			buttonDelete.TabIndex = 6;
			buttonDelete.Text = "Изтрий";
			buttonDelete.UseVisualStyleBackColor = true;
			// 
			// textBoxTownName
			// 
			textBoxTownName.BackColor = SystemColors.ControlLight;
			textBoxTownName.Location = new Point(15, 40);
			textBoxTownName.Name = "textBoxTownName";
			textBoxTownName.ReadOnly = true;
			textBoxTownName.Size = new Size(277, 27);
			textBoxTownName.TabIndex = 5;
			// 
			// labelDeleteTown
			// 
			labelDeleteTown.AutoSize = true;
			labelDeleteTown.Location = new Point(12, 9);
			labelDeleteTown.Name = "labelDeleteTown";
			labelDeleteTown.Size = new Size(282, 20);
			labelDeleteTown.TabIndex = 4;
			labelDeleteTown.Text = "Моля потвърдете изтриването на град:";
			// 
			// FormDeleteTown
			// 
			AutoScaleDimensions = new SizeF(8F, 20F);
			AutoScaleMode = AutoScaleMode.Font;
			ClientSize = new Size(301, 123);
			Controls.Add(buttonCancel);
			Controls.Add(buttonDelete);
			Controls.Add(textBoxTownName);
			Controls.Add(labelDeleteTown);
			FormBorderStyle = FormBorderStyle.FixedDialog;
			MaximizeBox = false;
			MinimizeBox = false;
			Name = "FormDeleteTown";
			StartPosition = FormStartPosition.CenterParent;
			Text = "Изтриване на град";
			ResumeLayout(false);
			PerformLayout();
		}

		#endregion

		private Button buttonCancel;
		private Button buttonDelete;
		private TextBox textBoxTownName;
		private Label labelDeleteTown;
	}
}
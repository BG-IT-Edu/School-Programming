﻿namespace WinFormsAppTownsDb
{
	public partial class FormCreateNewTown : Form
	{
		public FormCreateNewTown()
		{
			InitializeComponent();
		}

        public string TownName => this.textBoxTownName.Text;
    }
}

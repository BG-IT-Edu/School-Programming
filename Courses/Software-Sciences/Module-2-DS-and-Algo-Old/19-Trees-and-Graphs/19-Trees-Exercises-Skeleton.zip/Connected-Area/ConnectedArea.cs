﻿using System;

class ConnectedArea
{
    static void Main()
    {
        
    }

    static void ReadMatrix()
    {
    }

    private static int FindArea(int row, int col)
    {
        return -1;
    }
    
}

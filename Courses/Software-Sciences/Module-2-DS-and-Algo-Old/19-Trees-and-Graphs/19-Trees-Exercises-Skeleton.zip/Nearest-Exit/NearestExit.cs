﻿using Nearest_Exit;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

public class NearestExit
{
    //static void ReadLabyrinth()

    public static void Main()
    {
        //ReadLabyrinth();
    }

    static string FindShortestPathToExit()
    {
        return null;
    }

    static string TracePathBack(Point currentCell)
    {
        return null;
    }

    static void TryDirection(Queue<Point> queue, Point currentCell, string direction, int deltaX, int deltaY)
    {
    }

    static bool IsExit(Point currentCell)
    {
        return true;
    }

    static Point FindStartPosition()
    {
        return null;
    }
}

﻿using System;
using System.Collections.Generic;
using System.Text;

namespace BirthdayCelebrations
{
    public interface IIdentification
    {
        public string Id { get;}
    }
}

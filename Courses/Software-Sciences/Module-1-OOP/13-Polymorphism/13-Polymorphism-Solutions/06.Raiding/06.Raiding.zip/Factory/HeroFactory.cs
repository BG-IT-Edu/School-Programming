﻿namespace Raiding
{
    public abstract class HeroFactory
    {
        public abstract BaseHero GetHero();
    }
}

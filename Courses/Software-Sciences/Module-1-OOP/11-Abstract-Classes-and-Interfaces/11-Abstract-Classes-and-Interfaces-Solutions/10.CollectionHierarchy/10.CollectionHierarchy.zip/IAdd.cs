﻿using System;
using System.Collections.Generic;
using System.Text;

namespace CollectionHierarchy
{
    public abstract class IAdd
    {
        public abstract int Add(string element);
    }
}

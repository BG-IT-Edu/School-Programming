﻿using System;
using System.Collections.Generic;
using System.Text;

namespace CollectionHierarchy
{
    public abstract class IRemove : IAdd
    {
        public abstract string Remove();
    }
}

﻿using System;
namespace BorderControl
{
    public interface IId
    {
        string ID { get; }
    }
}

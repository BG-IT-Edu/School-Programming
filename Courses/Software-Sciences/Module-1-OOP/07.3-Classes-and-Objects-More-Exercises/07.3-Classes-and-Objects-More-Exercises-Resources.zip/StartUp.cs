﻿namespace Education
{
    public class StartUp
    {
        static void Main()
        {
            Specialty specialty1 = new Specialty(
                "Profile 'Software and hardware sciences'",
                "profile training with a focus on informatics, IT, and math"
            );

            Specialty specialty2 = new Specialty(
                "Profession 'Applied Programmer'",
                "professional training with a focus on programming and software development"
            );

            Group group1 = new Group("9A", new List<Student>());
            Group group2 = new Group("9B", new List<Student>());

            Student student1 = new Student("Stefan Kirov", 16, group1, specialty2);
            Student student2 = new Student("Kiril Valchev", 15, group1, specialty2);
            Student student3 = new Student("Mariela Draganova", 16, group1, specialty2);
            Student student4 = new Student("Denica Ivanova", 15, group2, specialty1);
            Student student5 = new Student("Georgi Petkanov", 16, group2, specialty1);
            Student student6 = new Student("Petar Ivanov", 16, group2, specialty1);

            Teacher teacher1 = new Teacher("A. Grigorov", "Math and Physics");
            Teacher teacher2 = new Teacher("M. Stefanova", "English");
            Teacher teacher3 = new Teacher("G. Angelov", "IT and Informatics");

            Course course1 = new Course("English language and culture", teacher2, group1);
            Course course2 = new Course("Programming basics", teacher3, group2);
            Course course3 = new Course("Programming advanced", teacher3, group2);

            Grade grade1 = new Grade(student1, course2, "11.02.2023", 5.50);
            Grade grade2 = new Grade(student1, course2, "20.05.2023", 6.00);
            Grade grade3 = new Grade(student3, course2, "07.03.2023", 5.25);
            Grade grade4 = new Grade(student3, course1, "08.03.2023", 6.00);
            Grade grade5 = new Grade(student3, course2, "17.04.2023", 5.75);

            List<Specialty> specialties = new List<Specialty> { specialty1, specialty2 };
            List<Student> students = new List<Student> { 
                student1, student2, student3, student4, student5, student6 };
            List<Group> groups = new List<Group> { group1, group2 };
            List<Teacher> teachers = new List<Teacher> { teacher1, teacher2, teacher3 };
            List<Course> courses = new List<Course> { course1, course2, course3 };
            List<Grade> grades = new List<Grade> { grade1, grade2, grade3, grade4, grade5 };

            School school1 = new School(
                "Professional high school of computer science",
                "Sofia",
                specialties,
                students,
                groups,
                teachers,
                courses,
                grades
            );

            List<School> schools = new List<School> { school1 };

            string? command = Console.ReadLine();

            while (command?.ToUpper() != "END")
            {
                List<string>? tokens = command?.Split(" \"").ToList();
                string? action = null;
                if (tokens != null && tokens.Count > 0)
                    action = tokens[0];
                string? name = null;
				if (tokens != null && tokens.Count > 1)
					name = tokens[1];

				if (action == "FIND_SPECIALTY")
                {
                    Specialty? specialty = specialties.Find(s => s.Name == name);
                    if (specialty != null)
                        Console.WriteLine($"{name} offers {specialty.Description}.");
                    else
						Console.WriteLine("NOT FOUND");
				}
				else if (action == "FIND_GROUP")
                {
                    Group? group = groups.Find(g => g.Name == name);
					if (group != null)
						Console.WriteLine($"Group {name} includes {String.Join(", ", group.Students.Select(student => student.Name))}.");
					else
						Console.WriteLine("NOT FOUND");
                }
                else if (action == "FIND_STUDENT")
                {
                    Student? student = students.Find(s => s.Name == name);
                    if (student != null)
                        Console.WriteLine($"{name} is {student?.Age} years old and studies in {student?.Group.Name} group.");
					else
						Console.WriteLine("NOT FOUND");
				}
                else if (action == "FIND_TEACHER")
                {
                    Teacher? teacher = teachers.Find(t => t.Name == name);
                    if (teacher != null)
                        Console.WriteLine($"{name} teaches {teacher.Competence}.");
					else
						Console.WriteLine("NOT FOUND");
				}
                else if (action == "FIND_COURSE")
                {
                    Course? course = courses.Find(c => c.Name == name);
                    if (course != null)
                        Console.WriteLine($"The students from {course.Group.Name} are taking {name} with {course.Teacher.Name}.");
					else
						Console.WriteLine("NOT FOUND");
				}
                else if (action == "FIND_GPA")
                {
                    Student? student = students.Find(s => s.Name == name);
                    if (student != null)
                    {
                        List<Grade> studentGrades = grades.FindAll(g => g.Student.Name == name);
                        double totalGrade = studentGrades.Sum(g => g.CourseGrade);
                        double gpa = totalGrade / studentGrades.Count;
                        Console.WriteLine($"{name}'s GPA is {gpa:f2}.");
                    }
				    else
                        Console.WriteLine("NOT FOUND");
				}
				else if (action == "FIND_SCHOOL")
                {
                    School? school = schools.Find(s => s.Name == name);
                    if (school != null)
                    {
                        Console.WriteLine($"{name} offers the following specialties:");
                        foreach (Specialty specialty in specialties)
                            Console.WriteLine($"- {specialty.Name}");
                    }
					else
						Console.WriteLine("NOT FOUND");
				}
                else
                {
					Console.WriteLine("INVALID COMMAND");
				}

				command = Console.ReadLine();
            }
        }
    }
}
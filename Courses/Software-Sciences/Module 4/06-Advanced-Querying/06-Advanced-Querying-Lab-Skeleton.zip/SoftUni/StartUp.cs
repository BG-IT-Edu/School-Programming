﻿using Microsoft.EntityFrameworkCore;
using SoftUni.Data;
using System.Linq;


namespace SoftUni
{
    public class StartUp
    {
        static void Main()
        {
            var context = new SoftUniContext();
            
        }

    }
}

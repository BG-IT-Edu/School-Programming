﻿using System;

namespace MusicProvider
{
    class Startup
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Hello World!");
        }
    }
}

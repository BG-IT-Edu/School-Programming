﻿using System;
using System.Linq;
using System.Text;
using System.Globalization;
using Diablo.Data;
using Diablo.Data.Models;

namespace Diablo
{
    public class StartUp
    {
        static void Main()
        {
            DiabloContext context = new DiabloContext();

        }

        //public static string CharactersInformation(DiabloContext context, int luck)
        //{

        //}

        //public static string GameTypesInformation(DiabloContext context, int idGameType)
        //{
           
        //}
        //public static string UserGamesInformation(DiabloContext context, int userId)
        //{
           
        //}
    }
}

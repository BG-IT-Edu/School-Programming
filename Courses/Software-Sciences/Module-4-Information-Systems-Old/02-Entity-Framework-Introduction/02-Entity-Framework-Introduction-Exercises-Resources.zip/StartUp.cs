﻿using System;
using System.Linq;
using System.Text;
using System.Globalization;
using Diablo.Data;
using Diablo.Models;

namespace Diablo
{
    public class StartUp
    {
        static void Main()
        {

        }

        //public static string GetGamesInformation(DiabloContext context)
        //{
        //}

        //public static string GetItemsWithPriceOver790(DiabloContext context)
        //{
        //}

        //public static string GetItemWithTypeAxe(DiabloContext context)
        //{
        //}

        //public static string AddNewGame(DiabloContext context)
        //{
        //}

        //public static string GetUsersAndGamesInformation(DiabloContext context)
        //{
        //}

        //public static string GetUsersGames(DiabloContext context)
        //{
        //}

        //public static string GetUsersWithMoreThan5Games(DiabloContext context)
        //{
        //}

        //public static string IncreasePrice(DiabloContext context)
        //{
        //}

    }
}

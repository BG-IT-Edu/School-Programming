﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Threading.Tasks;
using WebApplicationFileBrowser.Models;

namespace WebApplicationFileBrowser.Controllers
{
    public class HomeController : Controller
    {
        private readonly ILogger<HomeController> _logger;

        public HomeController(ILogger<HomeController> logger)
        {
            _logger = logger;
        }

        public IActionResult Index()
        {
            return View();
        }

        public IActionResult Privacy()
        {
            return View();
        }

        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error()
        {
            return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
        }

        public IActionResult Files(string path = @"C:\")
        {
            var parentDir = Directory.GetParent(path);
            var model = new FilesFolderModel()
            {
                ParentFolder = parentDir?.FullName,
                Folders = Directory.GetDirectories(path).ToArray(),
                Files = Directory.GetFiles(path).ToArray()
            };
            return View(model);
        }

        public FileResult DownloadFile(string path)
        {
            byte[] bytes = System.IO.File.ReadAllBytes(path);
            FileInfo fInfo = new FileInfo(path);
            return File(bytes, "application/octet-stream", fInfo.Name);
        }
    }
}

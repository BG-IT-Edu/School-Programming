﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace WebApplicationFileBrowser.Models
{
    public class FilesFolderModel
    {
        public string ParentFolder { get; set; }
        public string[] Folders { get; set; }
        public string[] Files { get; set; }
    }
}

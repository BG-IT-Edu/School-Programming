﻿using AutoMapper;
using SoftUni.Data;
using SoftUni.Dto;
using SoftUni.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace SoftUni.Controllers
{
    public class EmployeeController
    {
        private readonly SoftUniContext context;

        public EmployeeController(SoftUniContext context)
        {
            //Set the Context
           
        }

        public EmployeeDtoViewModel GetEmployeeInfo(int id)
        {
            //Initialize the mapper
           
            //Using automapper
           
            return dto;
        }
    }
}

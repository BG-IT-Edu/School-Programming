﻿using System;
using System.Collections.Generic;
using System.Text;

namespace SoftUni.Dto
{
    public class EmployeeDtoViewModel
    {
        // Get the needed properties for the model: Employee Id, First Name, Last Name, Middle Name, Job Title and Salary
       
    }
}

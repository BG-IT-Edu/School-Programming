﻿using System.Collections.Generic;

namespace People
{
    public class PersonCollection
    {
        private readonly Dictionary<string, Person> peopleByEmail;
        private readonly Dictionary<string, SortedSet<Person>> peopleByEmailDomain;
        private readonly Dictionary<string, SortedSet<Person>> peopleByNameAndTown;

        public PersonCollection()
        {
            this.peopleByEmail = new Dictionary<string, Person>();
            this.peopleByEmailDomain = new Dictionary<string, SortedSet<Person>>();
            this.peopleByNameAndTown = new Dictionary<string, SortedSet<Person>>();
        }

        public int Count => this.peopleByEmail.Count;

        public bool AddPerson(string email, string name, int age, string town)
        {
            if (this.peopleByEmail.ContainsKey(email))
            {
                return false;
            }

            Person person = new Person(email, name, age, town);
            this.peopleByEmail.Add(email, person);

            string emailDomain = email.Split('@')[1];
            this.peopleByEmailDomain.AppendValueToKey(emailDomain, person);
            this.peopleByNameAndTown.AppendValueToKey($"{name} {town}", person);

            return true;
        }

        public Person FindPerson(string email)
        {
            this.peopleByEmail.TryGetValue(email, out Person person);
            return person;
        }

        public bool DeletePerson(string email)
        {
            Person person = this.FindPerson(email);
            if (person == null)
            {
                return false;
            }

            this.peopleByEmail.Remove(email);

            string domain = email.Split("@")[1];
            this.peopleByEmailDomain[domain].Remove(person);
            this.peopleByNameAndTown[$"{person.Name} {person.Town}"].Remove(person);

            return true;
        }

        public IEnumerable<Person> FindPeople2(string emailDomain)
        {
            return this.peopleByEmailDomain.GetValuesForKey(emailDomain);
        }

        public IEnumerable<Person> FindPeople(string name, string town)
        {
            return this.peopleByNameAndTown.GetValuesForKey($"{name} {town}");
        }
    }
}

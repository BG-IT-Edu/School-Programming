﻿using System;
using System.Collections.Generic;

using Wintellect.PowerCollections;

namespace ShoppingCenter
{
    public class ShoppingStructure
    {
        private const string NotFoundMessage = "No products found";

        private readonly Dictionary<string, OrderedBag<Product>> productsByName;
        private readonly Dictionary<string, OrderedBag<Product>> productsByProducer;
        private readonly OrderedDictionary<decimal, OrderedBag<Product>> productsByPrice;
        private readonly Dictionary<string, OrderedBag<Product>> byNameAndProducer;

        public ShoppingStructure()
        {
            this.productsByName = new Dictionary<string, OrderedBag<Product>>();
            this.productsByProducer = new Dictionary<string, OrderedBag<Product>>();
            this.productsByPrice = new OrderedDictionary<decimal, OrderedBag<Product>>();
            this.byNameAndProducer = new Dictionary<string, OrderedBag<Product>>();
        }

        public string AddProduct(string name, decimal price, string producer)
        {
            Product product = new Product(name, price, producer);

            this.productsByName.AddValueToCollection(name, product);
            this.productsByProducer.AddValueToCollection(producer, product);
            this.productsByPrice.AddValueToCollection(price, product);
            this.byNameAndProducer.AddValueToCollection($"{name}{producer}", product);

            return "Product added";
        }

        public string DeleteProducts(string producer)
        {
            if (!this.productsByProducer.ContainsKey(producer))
            {
                return NotFoundMessage;
            }

            OrderedBag<Product> products = this.productsByProducer[producer];
            foreach (Product product in products)
            {
                this.productsByPrice[product.Price].Remove(product);
                this.productsByName[product.Name].Remove(product);
                this.byNameAndProducer[product.Name + product.Producer].Remove(product);
            }

            this.productsByProducer.Remove(producer);
            return $"{products.Count} products deleted";
        }

        public string DeleteProducts(string name, string producer)
        {
            string key = $"{name}{producer}";
            if (!this.byNameAndProducer.ContainsKey(key))
            {
                return NotFoundMessage;
            }

            OrderedBag<Product> products = this.byNameAndProducer[key];
            foreach (Product product in products)
            {
                this.productsByName[product.Name].Remove(product);
                this.productsByPrice[product.Price].Remove(product);
                this.productsByProducer[product.Producer].Remove(product);
            }

            this.byNameAndProducer.Remove(key);
            return $"{products.Count} products deleted";
        }

        public string FindProductsByName(string name)
        {
            if (!this.productsByName.ContainsKey(name))
            {
                return NotFoundMessage;
            }

            IEnumerable<Product> products = this.productsByName[name];
            return this.PrintProducts(products);
        }

        public string FindProductsByProducer(string producer)
        {
            if (!this.productsByProducer.ContainsKey(producer))
            {
                return NotFoundMessage;
            }

            IEnumerable<Product> products = this.productsByProducer[producer];
            return this.PrintProducts(products);
        }

        public string FindProductsByPriceRange(decimal startPrice, decimal endPrice)
        {
            OrderedBag<Product> products = new OrderedBag<Product>();
            var targetProductsByPrice = this.productsByPrice.Range(
                startPrice, true, endPrice, true);

            foreach (KeyValuePair<decimal, OrderedBag<Product>> productByPrice in targetProductsByPrice)
            {
                foreach (Product product in productByPrice.Value)
                {
                    products.Add(product);
                }
            }

            return this.PrintProducts(products);
        }

        private string PrintProducts(IEnumerable<Product> products)
        {
            string result = string.Join(Environment.NewLine, products);
            return string.IsNullOrEmpty(result) ? NotFoundMessage : result;
        }
    }
}

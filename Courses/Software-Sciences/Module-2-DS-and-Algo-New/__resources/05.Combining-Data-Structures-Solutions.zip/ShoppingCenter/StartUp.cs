﻿using System;
using System.Text;

namespace ShoppingCenter
{
    public class StartUp
    {
        public static void Main()
        {
            ShoppingStructure structure = new ShoppingStructure();
            StringBuilder sb = new StringBuilder();

            int commandsCount = int.Parse(Console.ReadLine());
            for (int i = 0; i < commandsCount; i++)
            {
                string input = Console.ReadLine();

                string command = input[..input.IndexOf(' ')];
                string[] data = input[(input.IndexOf(' ') + 1)..].Split(';');
                string result = string.Empty;

                if (command == "AddProduct")
                {
                    string name = data[0];
                    decimal price = decimal.Parse(data[1]);
                    string producer = data[2];
                    result = structure.AddProduct(name, price, producer);
                }
                else if (command == "DeleteProducts")
                {
                    if (data.Length == 1)
                    {
                        string producer = data[0];
                        result = structure.DeleteProducts(producer);
                    }
                    else
                    {
                        string producer = data[1];
                        string name = data[0];
                        result = structure.DeleteProducts(name, producer);
                    }
                }
                else if (command == "FindProductsByName")
                {
                    string name = data[0];
                    result = structure.FindProductsByName(name);
                }
                else if (command == "FindProductsByProducer")
                {
                    string producer = data[0];
                    result = structure.FindProductsByProducer(producer);
                }
                else if (command == "FindProductsByPriceRange")
                {
                    decimal startPrice = decimal.Parse(data[0]);
                    decimal endPrice = decimal.Parse(data[1]);
                    result = structure.FindProductsByPriceRange(startPrice, endPrice);
                }

                sb.AppendLine(result);
            }

            Console.WriteLine(sb);
        }
    }
}

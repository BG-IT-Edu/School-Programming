﻿using System;

namespace VariationsNoRepetition
{
    public class VariationNoRepetition
    {
        private static int k;
        private static string[] input;
        private static string[] variations;
        private static bool[] isUsed;

        public static void Main()
        {
            input = Console.ReadLine()
                .Split();
            k = int.Parse(Console.ReadLine());
            variations = new string[k];
            isUsed = new bool[input.Length];

            GenerateVariations(0);
        }

        private static void GenerateVariations(int index)
        {
            if (index >= variations.Length)
            {
                Console.WriteLine(string.Join(" ", variations));
                return;
            }

            for (int currentIndex = 0; currentIndex < input.Length; currentIndex++)
            {
                if (!isUsed[currentIndex])
                {
                    isUsed[currentIndex] = true;
                    variations[index] = input[currentIndex];
                    GenerateVariations(index + 1);
                    isUsed[currentIndex] = false;
                }
            }
        }
    }
}

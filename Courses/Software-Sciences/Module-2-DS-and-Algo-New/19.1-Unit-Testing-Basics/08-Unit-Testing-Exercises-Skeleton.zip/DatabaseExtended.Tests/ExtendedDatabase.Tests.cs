using NUnit.Framework;
using P02_ExtendedDatabase;
using System;

namespace Tests
{
    public class ExtendedDatabaseTests
    {

        [SetUp]
        public void Setup()
        {
        }

        [Test]
        public void Test1()
        {
            Assert.Pass();
        }

    }
}
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _01.Resurrection
{
    class Program
    {
        static void Main(string[] args)
        {
            int n = int.Parse(Console.ReadLine());
            decimal years = 0;
            for (int i = 0; i < n; i++)
            {
                long totalLength = long.Parse(Console.ReadLine());
                decimal totalwidth = decimal.Parse(Console.ReadLine());
                int wingLength = int.Parse(Console.ReadLine());

                years = (totalLength * totalLength) * ((totalwidth) + 2 * wingLength);

            Console.WriteLine(years);
            }
        }
    }
}

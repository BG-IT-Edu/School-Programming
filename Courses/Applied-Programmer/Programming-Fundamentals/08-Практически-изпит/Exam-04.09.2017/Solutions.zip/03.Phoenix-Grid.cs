using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;

namespace A03
{
    class Program
    {
        static void Main(string[] args)
        {
            Regex pattern = new Regex(@"^([^\s_]{3})(\.[^\s_]{3})*$");


            string input = Console.ReadLine().Trim();

            while (input != "ReadMe")
            {
                char[] inputArray = input.ToCharArray();
                Array.Reverse(inputArray);
                string revercedImput = string.Join("", inputArray);

                if (input == revercedImput && pattern.IsMatch(input))
                {
                    Console.WriteLine("YES");
                }
                else
                {
                    Console.WriteLine("NO");
                }

                input = Console.ReadLine();
            }
        }
    }
}

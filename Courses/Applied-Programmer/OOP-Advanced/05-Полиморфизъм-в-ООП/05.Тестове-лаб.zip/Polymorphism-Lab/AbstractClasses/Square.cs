﻿public class Square
{
}

﻿namespace AspNetCoreSecurityDemo.Data
{
    public class DataValue
    {
        public int Id { get; set; }

        public string Name { get; set; }

        public string Value { get; set; }
    }
}

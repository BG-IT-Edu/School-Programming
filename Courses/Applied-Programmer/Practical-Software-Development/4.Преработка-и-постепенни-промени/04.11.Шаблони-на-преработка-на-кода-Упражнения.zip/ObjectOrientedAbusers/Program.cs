﻿namespace ObjectOrientedAbusers
{
    class Program
    {
        static void Main()
        {
            // https://github.com/EnterpriseQualityCoding/FizzBuzzEnterpriseEdition
        }
    }
}

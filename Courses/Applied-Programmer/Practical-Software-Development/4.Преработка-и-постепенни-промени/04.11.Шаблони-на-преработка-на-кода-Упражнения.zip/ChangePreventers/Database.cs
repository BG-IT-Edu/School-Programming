﻿namespace ChangePreventers
{
    public static class Database
    {
        public static string DbConnectionString = "...";

        public static void ConnectToDb()
        {
        }

        public static void GetCustomers()
        {
        }

        // ...
    }
}

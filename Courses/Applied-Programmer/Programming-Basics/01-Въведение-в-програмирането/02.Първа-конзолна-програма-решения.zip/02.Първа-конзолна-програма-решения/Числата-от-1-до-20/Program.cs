﻿using System;

namespace Nums1to20
{
    class Program
    {
        //3.Числата от 1 до 20
        static void Main(string[] args)
        {
            Console.WriteLine(1);
            Console.WriteLine(2);
            Console.WriteLine(3);
            Console.WriteLine(4);
            Console.WriteLine(5);
            Console.WriteLine(6);
            Console.WriteLine(7);
            Console.WriteLine(8);
            Console.WriteLine(9);
            Console.WriteLine(10);
            Console.WriteLine(11);
            Console.WriteLine(12);
            Console.WriteLine(13);
            Console.WriteLine(14);
            Console.WriteLine(15);
            Console.WriteLine(16);
            Console.WriteLine(17);
            Console.WriteLine(18);
            Console.WriteLine(19);
            Console.WriteLine(20);
        }
    }
}

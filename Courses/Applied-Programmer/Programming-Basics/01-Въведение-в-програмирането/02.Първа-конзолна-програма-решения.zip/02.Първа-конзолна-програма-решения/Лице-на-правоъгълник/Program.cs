﻿using System;

namespace RectangleArea
{
    class Program
    {
        //5.*Лице на правоъгълник
        static void Main(string[] args)
        {
            var a = double.Parse(Console.ReadLine());
            var b = double.Parse(Console.ReadLine());

            Console.WriteLine(a * b);
        }
    }
}

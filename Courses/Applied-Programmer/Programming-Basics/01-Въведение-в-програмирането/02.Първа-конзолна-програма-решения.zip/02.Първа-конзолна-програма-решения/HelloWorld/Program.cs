﻿using System;

namespace HelloWorld
{
    class Program
    {
        //1.Hello World
        static void Main(string[] args)
        {
            Console.WriteLine("Hello World!");
        }
    }
}

﻿using System;

namespace TriangleOf55Stars
{
    class Program
    {
        //4.Триъгълник от 55 звездички
        static void Main(string[] args)
        {
            Console.WriteLine("*");
            Console.WriteLine("**");
            Console.WriteLine("***");
            Console.WriteLine("****");
            Console.WriteLine("*****");
            Console.WriteLine("******");
            Console.WriteLine("*******");
            Console.WriteLine("********");
            Console.WriteLine("*********");
            Console.WriteLine("**********");
        }
    }
}
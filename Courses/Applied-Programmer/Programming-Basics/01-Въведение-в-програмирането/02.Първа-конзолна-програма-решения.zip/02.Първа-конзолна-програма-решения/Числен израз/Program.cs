﻿using System;

namespace Expression
{
    class Program
    {
        //2.Числен израз
        static void Main(string[] args)
        {
            Console.WriteLine((3522 + 52353) * 23 - (2336 * 501 + 23432 - 6743) * 3);
        }
    }
}
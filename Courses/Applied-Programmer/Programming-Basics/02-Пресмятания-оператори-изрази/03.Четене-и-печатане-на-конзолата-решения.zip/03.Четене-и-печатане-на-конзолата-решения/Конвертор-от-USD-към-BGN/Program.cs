﻿using System;

namespace USD_to_BGN
{
    class Program
    {
        //7.*Конвертор от USD към BGN
        static void Main(string[] args)
        {
            double USD = double.Parse(Console.ReadLine());
            double BGN = USD * 1.79549;
            Console.WriteLine(Math.Round(BGN, 2) + " BGN");
        }
    }
}

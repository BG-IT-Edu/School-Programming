﻿using System;

namespace Radians_To_Degrees
{
    class Program
    {
        //6.*Конвертор от радиани в градуси 
        static void Main(string[] args)
        {
            double r = double.Parse(Console.ReadLine());
            double g = r * 180 / Math.PI;
            Console.WriteLine(Math.Round(g));
        }
    }
}

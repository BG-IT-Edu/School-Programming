﻿using System;

namespace SquareArea
{
    class Program
    {
        //1.Пресмятане на лице на квадрат
        static void Main(string[] args)
        {
            Console.Write("a = ");
            var a = int.Parse(Console.ReadLine());
            var area = a * a;
            Console.Write("Square = ");
            Console.WriteLine(area);
        }
    }
}
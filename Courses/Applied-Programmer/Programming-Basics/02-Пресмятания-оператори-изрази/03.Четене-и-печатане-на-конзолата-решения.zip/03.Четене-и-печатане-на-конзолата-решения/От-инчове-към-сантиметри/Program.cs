﻿using System;

namespace Inches_To_Centimetres
{
    class Program
    {
        //2.От инчове към сантиметри
        static void Main(string[] args)
        {
            Console.Write("inches = ");
            var inches = double.Parse(Console.ReadLine());
            var centimetres = inches * 2.54;
            Console.Write("centimeters = ");
            Console.WriteLine(centimetres);
        }
    }
}
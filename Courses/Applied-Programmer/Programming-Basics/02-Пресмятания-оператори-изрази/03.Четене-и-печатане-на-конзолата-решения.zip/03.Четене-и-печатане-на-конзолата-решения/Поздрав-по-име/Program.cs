﻿using System;

namespace Greeting
{
    class Program
    {
        //3.Поздрав по име
        static void Main(string[] args)
        {
            Console.Write("Enter your name: ");
            var name = Console.ReadLine();
            Console.WriteLine("Hello, {0}!", name);
        }
    }
}
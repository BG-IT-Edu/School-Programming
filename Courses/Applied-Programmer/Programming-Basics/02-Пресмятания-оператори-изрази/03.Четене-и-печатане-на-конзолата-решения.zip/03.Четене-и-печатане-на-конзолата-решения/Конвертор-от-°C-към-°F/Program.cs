﻿using System;

namespace Celsius_To_Fahrenheit
{
    class Program
    {
        //5.*Конвертор от °C към °F 
        static void Main(string[] args)
        {
            var a = double.Parse(Console.ReadLine());
            var b = a * 1.8 + 32;
            Console.WriteLine(b);
        }
    }
}
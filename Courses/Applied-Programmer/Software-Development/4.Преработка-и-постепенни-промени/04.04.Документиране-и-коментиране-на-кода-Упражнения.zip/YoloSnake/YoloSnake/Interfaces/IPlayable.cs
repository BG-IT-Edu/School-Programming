﻿namespace YoloSnake.Interfaces
{
    public interface IPlayable : IDrawable, IMovable
    {
    }
}
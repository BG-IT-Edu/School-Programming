﻿namespace YoloSnake.Enums
{
    public enum Direction
    {
        Up,
        Down,
        Left,
        Right
    }
}
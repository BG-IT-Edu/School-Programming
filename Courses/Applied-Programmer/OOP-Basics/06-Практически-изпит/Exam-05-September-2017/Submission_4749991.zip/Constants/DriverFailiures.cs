﻿public class DriverFailiures
{
    public const string BlownTyre = "Blown Tyre";
    public const string OutOfFuel = "Out of fuel";
    public const string Crashed = "Crashed";
}
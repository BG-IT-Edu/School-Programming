﻿namespace DungeonsAndCodeWizards.Entities.Characters.Enums
{
	public enum Faction
	{
		CSharp,
		Java
	}
}

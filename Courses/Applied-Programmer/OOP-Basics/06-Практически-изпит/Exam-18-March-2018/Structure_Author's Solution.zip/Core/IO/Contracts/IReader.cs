﻿namespace DungeonsAndCodeWizards.Core.IO.Contracts
{
	public interface IReader
	{
		string ReadLine();
	}
}
